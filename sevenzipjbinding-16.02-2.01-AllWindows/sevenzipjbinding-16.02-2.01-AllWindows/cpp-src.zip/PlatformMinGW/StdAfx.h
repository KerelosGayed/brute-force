#ifndef __STDAFX_H__INCLUDED__
#define __STDAFX_H__INCLUDED__

#ifndef NO_MY_STDAFX
  #include <windows.h>
  #include <time.h>
#endif // NO_MY_STDAFX

#endif // __STDAFX_H__INCLUDED__
